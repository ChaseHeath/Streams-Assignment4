#include "Stream.h"
#include <assert.h>
#include <iostream>

using namespace stream;

int main() {
	// Put your "unit test" codes here
	auto s = stream::empty<int>(); // Creates an empty stream of integers
	for (int i = 0; i < 100; i++)
		assert(!s.next()); // Calling next() always yields an empty value
	// Example:
	auto e = stream::once(2);
	auto opInt = e.next();
	// The first element pulled from s0 holds 2
	assert(opInt && *opInt == 2);
	// Subsequent next() invocation always yield empty value
	for (int i = 0; i < 100; i++)
		assert(!e.next());	// auto testStream = take(hamming(), 20);
	// while (auto elem = testStream.next())
	//	std::cout << *elem << std::endl;
	auto c = chain(once(2), once(3));
	auto first = c.next();
	assert(first && *first == 2);
	auto second = c.next();
	assert(second && *second == 3);
	// All elements from both streams are exhausted
	assert(!c.next());
	auto s0 = counter(1);   // s0 = { 1, 2, 3, ... }
	auto s1 = take(s0, 2);  // s1 = { 1, 2 }
	auto s12 = s1.next();
	auto s13 = s1.next();
	auto s14 = s1.next();
	assert(s12 && *s12 == 1);
	assert(s13 && *s13 == 2);
	assert(!s14);

	auto t0 = counter(1);     // s0 = { 1, 2, 3, ... }
// filter out all odd numbers
std::function<bool(int)> f = [] (int num) { return num % 2 == 0; };
auto t1 = filter(t0, f); 

}
