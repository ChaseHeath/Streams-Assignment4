#include "Stream.h"

#include <iostream>

using namespace stream;

int main() {
	// Put your "unit test" codes here
	
	// Example:
	
	// auto testStream = take(hamming(), 20);
	// while (auto elem = testStream.next())
	//	std::cout << *elem << std::endl;
}
